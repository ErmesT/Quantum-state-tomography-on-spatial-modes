Quantum state tomography: quantum concepts and classical implementation with intense light
Ermes Toninelli, Bienvenu Ndagano, Adam Vallés, Bereneice Sephton, Isaac Nape, Antonio Ambrosio, Federico Capasso, Miles J. Padgett, and Andrew Forbes
http://dx.doi.org/10.5525/gla.researchdata.559

Detailed instructions of the contents of this archive are inside the individual compressed files.
More information about the supplied LabVIEW and Arduino code is available within the notes.pdf file.

Code 1-4 folders contain the LabVIEW programmes to automate the tomography experiment, optimise the choice of the pixel coordinates for the projection measurement, the Arduino firmware for the roto-flip stages, the 3D-design files of all components of the stages, and the video of the syste in action performing an automated state tomography measurement.

An updated version of this suplementary material is available on GitHub at the following address:
https://github.com/ErmesT/Quantum-state-tomography-on-spatial-modes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

This Arduino code was tested using the Arduino IDE version 1.8.5.
This sketch is the firmware that allows the roto-flip stages to communicate and be controlled by LabVIEW via the serial port.
More information about the code provided can be found in the attached .pdf notes (notes.pdf).
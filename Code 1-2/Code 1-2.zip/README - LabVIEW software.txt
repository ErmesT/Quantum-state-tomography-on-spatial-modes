Quantum state tomography: quantum concepts and classical implementation with intense light
Ermes Toninelli, Bienvenu Ndagano, Adam Vallés, Bereneice Sephton, Isaac Nape, Antonio Ambrosio, Federico Capasso, Miles J. Padgett, and Andrew Forbes
http://dx.doi.org/10.5525/gla.researchdata.559

Detailed instructions of the contents of this archive are inside the individual compressed files.
More information about the supplied LabVIEW and Arduino code is available within the notes.pdf file.

Code 1-4 folders contain the LabVIEW programmes to automate the tomography experiment, optimise the choice of the pixel coordinates for the projection measurement, the Arduino firmware for the roto-flip stages, the 3D-design files of all components of the stages, and the video of the syste in action performing an automated state tomography measurement.

An updated version of this suplementary material is available on GitHub at the following address:
https://github.com/ErmesT/Quantum-state-tomography-on-spatial-modes
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

These programmes were tested using National Instruments LabVIEW 2017 and Vision Sofware 2017. Third party dependencies (provided as part of this code) are also required and can be installed using the National Instruments VI Package Manager.

Below is a description of the code provided:
1) Dependencies. These are required to run the programmes and can be installed using NI VI Package Manager;
2) LabVIEW Automation Programme. This code allows to control four roto-flip stages and a connected CCD camera to perform an automated state tomography measurement. To run the programme open the "quantumStateTomography.vi" file within the "Project Files" folder. In the "Utilities" subfolder standalone programmes can be used to individually control the roto-flip stages and assist in the debugging of the system.
3) Folder "LabVIEW Optimiser Programme" contains the code required to analyse the data saved by the automation programme. To run the programme open the "optimiser.vi" file within the "Project Files" folder. The folder where the saved data is located needs to be specified before running the programme, together with the type of measurement (Bell or Tomography).

More information about the programmes can be found in the attached .pdf notes (notes.pdf).
